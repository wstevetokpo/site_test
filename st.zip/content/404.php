<title><?= lgg('Page introuvable') . ' - ' . APP_NAME ?></title>
La page que vous essayer de charger n\'est pas disponible sur le serveur.