<script src="<?= HOME_PATH ?>assets/js/all.min.js"></script>
<!-- <script src="<?= HOME_PATH ?>assets/js/main.js"></script> -->
<script src="<?= HOME_PATH ?>assets/js/vendor/jquery.min.js"></script>
<script src="<?= HOME_PATH ?>assets/js/vendor/imagesloaded.pkgd.min.js"></script>
<script src="<?= HOME_PATH ?>assets/js/vendor/preloader.min.js"></script>
<script src="<?= HOME_PATH ?>assets/js/vendor/inview.min.js"></script>
<script src="<?= HOME_PATH ?>assets/js/vendor/menu-engine.min.js"></script>
<script src="<?= HOME_PATH ?>assets/js/vendor/menu-grid.min.js"></script>
<script src="<?= HOME_PATH ?>assets/js/vendor/bootstrap.min.js"></script>
<script src="<?= HOME_PATH ?>assets/js/vendor/swiper.min.js"></script>
<script src="<?= HOME_PATH ?>assets/js/vendor/anime.min.js"></script>
<script src="<?= HOME_PATH ?>assets/js/vendor/dynamic-slider.min.js"></script>
<script src="<?= HOME_PATH ?>assets/js/vendor/shuffle.min.js"></script>
<script src="<?= HOME_PATH ?>assets/js/vendor/stickybits.min.js"></script>
<script src="<?= HOME_PATH ?>assets/js/vendor/bricklayer.min.js"></script>
<script src="<?= HOME_PATH ?>assets/js/vendor/lightbox.min.js"></script>
<script src="<?= HOME_PATH ?>assets/js/vendor/typed.min.js"></script>
<script src="<?= HOME_PATH ?>assets/js/vendor/progressbar.min.js"></script>
<script src="<?= HOME_PATH ?>assets/js/vendor/map-styles.min.js"></script>
<script src="<?= HOME_PATH ?>assets/js/vendor/magnetic-effect.min.js"></script>
<script src="<?= HOME_PATH ?>assets/js/vendor/gsap.min.js"></script>
<script src="<?= HOME_PATH ?>assets/js/vendor/aos.min.js"></script>
<script src="<?= HOME_PATH ?>assets/js/vendor/lax.min.js"></script>
<script src="<?= HOME_PATH ?>assets/js/vendor/cursor-effect.min.js"></script>

<script src="<?= HOME_PATH ?>assets/js/main.js"></script>